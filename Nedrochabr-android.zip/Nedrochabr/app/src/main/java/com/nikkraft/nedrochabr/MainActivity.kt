package com.nikkraft.nedrochabr

import android.Manifest
import android.app.*
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.*
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.view.View
import android.widget.RemoteViews
import org.json.JSONObject
import java.util.Calendar

class MainActivity : Activity() {
    lateinit var web: WebView
    var pendingExport = ""

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Bridge(this), "Android")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    override fun onResume() {
        super.onResume()
        web.evaluateJavascript("window.applyPending&&window.applyPending()", null)
    }

    @Deprecated("back")
    override fun onBackPressed() { moveTaskToBack(true) }

    @Deprecated("result")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (res != RESULT_OK || uri == null) return
        if (req == 100) {
            contentResolver.openOutputStream(uri)?.use { it.write(pendingExport.toByteArray(Charsets.UTF_8)) }
        } else if (req == 101) {
            val t = contentResolver.openInputStream(uri)?.use { String(it.readBytes(), Charsets.UTF_8) } ?: return
            web.evaluateJavascript("window.importText(" + JSONObject.quote(t) + ")", null)
        }
    }
}

class Bridge(private val a: MainActivity) {
    @JavascriptInterface
    fun setReminder(on: Int, h: Int, m: Int) {
        if (on == 1 && Build.VERSION.SDK_INT >= 33) {
            a.runOnUiThread { a.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1) }
        }
        Remind.set(a, on == 1, h, m)
    }

    @JavascriptInterface
    fun setStart(start: Double, slip: Int) {
        a.getSharedPreferences("state", 0).edit().putLong("start", start.toLong()).putBoolean("slip", slip == 1).apply()
        Wid.refresh(a)
    }

    @JavascriptInterface
    fun version(): String = a.packageManager.getPackageInfo(a.packageName, 0).versionName ?: ""

    @JavascriptInterface
    fun takePending(): String {
        val p = a.getSharedPreferences("state", 0)
        val s = p.getString("pending", "") ?: ""
        p.edit().putString("pending", "").apply()
        return s
    }

    @JavascriptInterface
    fun exportFile(text: String) {
        a.pendingExport = text
        a.runOnUiThread {
            val i = Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json")
            i.putExtra(Intent.EXTRA_TITLE, "nedrochabr-backup.json")
            a.startActivityForResult(i, 100)
        }
    }

    @JavascriptInterface
    fun importFile() {
        a.runOnUiThread {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
            a.startActivityForResult(i, 101)
        }
    }
}

object Remind {
    fun set(c: Context, on: Boolean, h: Int, m: Int) {
        c.getSharedPreferences("rem", 0).edit().putBoolean("on", on).putInt("h", h).putInt("m", m).apply()
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(c, 1, Intent(c, Rem::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        am.cancel(pi)
        if (!on) return
        val t = Calendar.getInstance()
        t.set(Calendar.HOUR_OF_DAY, h)
        t.set(Calendar.MINUTE, m)
        t.set(Calendar.SECOND, 0)
        if (t.timeInMillis <= System.currentTimeMillis()) t.add(Calendar.DAY_OF_YEAR, 1)
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, t.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
    }
}

class Rem : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("r", "Напоминание", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(1, Notification.Builder(c, "r")
            .setSmallIcon(android.R.drawable.ic_menu_my_calendar)
            .setContentTitle("Nedrochabr")
            .setContentText("Отметь сегодняшний день")
            .setContentIntent(open)
            .setAutoCancel(true)
            .addAction(Notification.Action.Builder(0, "Держусь", Mark.pi(c, 10, false)).build())
            .addAction(Notification.Action.Builder(0, "Срыв", Mark.pi(c, 11, true)).build())
            .build())
    }
}

class Boot : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val p = c.getSharedPreferences("rem", 0)
        Remind.set(c, p.getBoolean("on", false), p.getInt("h", 21), p.getInt("m", 0))
    }
}

object Mark {
    fun add(c: Context, bad: Boolean) {
        val n = Calendar.getInstance()
        if (n.get(Calendar.MONTH) != 10) return
        val p = c.getSharedPreferences("state", 0)
        val k = n.get(Calendar.YEAR).toString() + "-10-" + n.get(Calendar.DAY_OF_MONTH)
        val list = (p.getString("pending", "") ?: "").split(",").filter { it.isNotEmpty() }.toMutableList()
        val old = list.firstOrNull { it.startsWith(k + ":") }
        if (old != null && old.contains(":bad") && !bad) return
        list.removeAll { it.startsWith(k + ":") }
        val now = System.currentTimeMillis()
        list.add(if (bad) k + ":bad:" + now else k + ":ok")
        val e = p.edit().putString("pending", list.joinToString(",")).putString("mark", k + (if (bad) ":bad" else ":ok"))
        if (bad) e.putLong("start", now).putBoolean("slip", true)
        e.apply()
    }

    fun pi(c: Context, code: Int, bad: Boolean): PendingIntent =
        PendingIntent.getBroadcast(c, code, Intent(c, Act::class.java).putExtra("bad", bad), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
}

class Act : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Mark.add(c, i.getBooleanExtra("bad", false))
        Wid.refresh(c)
        (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(1)
    }
}

class Wid : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, build(c))
    }

    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        if (i.action == "com.nikkraft.nedrochabr.MARK") {
            Mark.add(c, false)
            refresh(c)
        } else if (i.action == "com.nikkraft.nedrochabr.SLIP") {
            val p = c.getSharedPreferences("state", 0)
            val now = System.currentTimeMillis()
            if (now - p.getLong("armed", 0L) < 5000L) {
                p.edit().putLong("armed", 0L).apply()
                Mark.add(c, true)
                refresh(c)
            } else {
                p.edit().putLong("armed", now).apply()
                refresh(c)
                val pr = goAsync()
                Handler(Looper.getMainLooper()).postDelayed({
                    refresh(c)
                    pr.finish()
                }, 5200)
            }
        }
    }

    companion object {
        fun build(c: Context): RemoteViews {
            val p = c.getSharedPreferences("state", 0)
            val start = p.getLong("start", 0L)
            val v = RemoteViews(c.packageName, R.layout.widget)
            if (start == 0L) {
                v.setTextViewText(R.id.wBig, "—")
                v.setTextViewText(R.id.wSmall, "Открой приложение")
                v.setChronometer(R.id.wChrono, SystemClock.elapsedRealtime(), null, false)
            } else {
                val ms = maxOf(0L, System.currentTimeMillis() - start)
                v.setTextViewText(R.id.wBig, (ms / 86400000L).toString() + " д")
                v.setTextViewText(R.id.wSmall, if (p.getBoolean("slip", false)) "с последнего срыва" else "с 1 ноября")
                v.setChronometer(R.id.wChrono, SystemClock.elapsedRealtime() - ms, null, true)
            }
            val n = Calendar.getInstance()
            val today = n.get(Calendar.YEAR).toString() + "-10-" + n.get(Calendar.DAY_OF_MONTH)
            val mark = p.getString("mark", "")
            if (n.get(Calendar.MONTH) != 10) {
                v.setTextViewText(R.id.wBtn, "Жди ноября")
                v.setViewVisibility(R.id.wBad, View.GONE)
            } else {
                v.setViewVisibility(R.id.wBad, View.VISIBLE)
                v.setTextViewText(R.id.wBtn, if (mark == today + ":ok") "Отмечено ✓" else "Держусь")
                val armed = System.currentTimeMillis() - p.getLong("armed", 0L) < 5000L
                v.setTextViewText(R.id.wBad, if (mark == today + ":bad") "Срыв ✗" else if (armed) "Точно?" else "Срыв")
            }
            val ok = Intent(c, Wid::class.java).setAction("com.nikkraft.nedrochabr.MARK")
            val bad = Intent(c, Wid::class.java).setAction("com.nikkraft.nedrochabr.SLIP")
            v.setOnClickPendingIntent(R.id.wBtn, PendingIntent.getBroadcast(c, 3, ok, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            v.setOnClickPendingIntent(R.id.wBad, PendingIntent.getBroadcast(c, 4, bad, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            v.setOnClickPendingIntent(R.id.wRoot, PendingIntent.getActivity(c, 2, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            return v
        }

        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            for (id in m.getAppWidgetIds(ComponentName(c, Wid::class.java))) m.updateAppWidget(id, build(c))
        }
    }
}
