plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
val runNo = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
android {
    namespace = "com.nikkraft.nedrochabr"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.nikkraft.nedrochabr"
        minSdk = 26
        targetSdk = 34
        versionCode = runNo
        versionName = "1.$runNo"
    }
    val ks = file("../release.jks")
    signingConfigs {
        create("release") {
            if (ks.exists()) {
                storeFile = ks
                storePassword = System.getenv("KS_PASS")
                keyAlias = "nedr"
                keyPassword = System.getenv("KS_PASS")
            }
        }
    }
    buildTypes {
        release {
            if (ks.exists()) signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = false
        }
    }
    lint { checkReleaseBuilds = false; abortOnError = false }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
