# Nedrochabr (Android)
WebView-обёртка над `app/src/main/assets/index.html`, напоминание, виджет (таймер + кнопка «Сегодня держусь»), экспорт/импорт файлом.
Сборка: GitHub Actions, подписанный APK появляется в Releases.
Подпись: секреты репозитория KS_B64 (keystore в base64) и KS_PASS. Ключа в репозитории нет.
Локально: положи release.jks рядом с settings.gradle.kts, задай KS_PASS, `gradle assembleRelease` (Gradle 8.9, JDK 17).
